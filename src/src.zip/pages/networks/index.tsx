
export function Networks(){
  return(
    <div>
      <h1>Página redes sociais</h1>
    </div>
  )
}